
const int tempPin = A0;
const int lightPin = A1;
const int potPin = A2;

void setup() {
  Serial.begin(9600);
}

void loop() {
  int tempRaw = analogRead(tempPin);
  int lightRaw = analogRead(lightPin);
  int potRaw = analogRead(potPin);

  Serial.print("Temperature Raw: ");
  Serial.print(tempRaw);

  Serial.print(" | Light Raw: ");
  Serial.print(lightRaw);

  Serial.print(" | Pot Raw: ");
  Serial.println(potRaw);

  delay(1000);
}
