
const int tempPin = A0;
const int lightPin = A1;
const int potPin = A2;

float tempData[10];
float lightData[10];
float potData[10];

int indexPos = 0;
int samples = 0;

unsigned long previousTime = 0;
const unsigned long interval = 1000;

void setup() {
  Serial.begin(9600);
  Serial.println("Time(s),Temperature(C),Light(%),Pot(%)");
}

void loop() {
  unsigned long now = millis();

  if (now - previousTime >= interval) {
    previousTime = now;

    int tempRaw = analogRead(tempPin);
    int lightRaw = analogRead(lightPin);
    int potRaw = analogRead(potPin);

    float temperature = tempRaw * 50.0 / 1023.0;
    float light = lightRaw * 100.0 / 1023.0;
    float pot = potRaw * 100.0 / 1023.0;

    tempData[indexPos] = temperature;
    lightData[indexPos] = light;
    potData[indexPos] = pot;

    Serial.print(now / 1000.0, 1);
    Serial.print(",");
    Serial.print(temperature, 2);
    Serial.print(",");
    Serial.print(light, 2);
    Serial.print(",");
    Serial.println(pot, 2);

    indexPos = (indexPos + 1) % 10;

    if (samples < 10) {
      samples++;
    }

    if (samples == 10 && indexPos == 0) {
      printSummary();
    }
  }
}

void printSummary() {
  Serial.println();
  Serial.println("Sensor       Average   Minimum   Maximum");
  Serial.println("----------------------------------------");

  printRow("Temperature", tempData);
  printRow("Light", lightData);
  printRow("Potentiometer", potData);

  Serial.println("----------------------------------------");
  Serial.println();
}

void printRow(const char* name, float data[]) {
  float total = 0;
  float minimum = data[0];
  float maximum = data[0];

  for (int i = 0; i < 10; i++) {
    total += data[i];

    if (data[i] < minimum) {
      minimum = data[i];
    }

    if (data[i] > maximum) {
      maximum = data[i];
    }
  }

  Serial.print(name);
  Serial.print("   ");
  Serial.print(total / 10.0, 2);
  Serial.print("      ");
  Serial.print(minimum, 2);
  Serial.print("      ");
  Serial.println(maximum, 2);
}
