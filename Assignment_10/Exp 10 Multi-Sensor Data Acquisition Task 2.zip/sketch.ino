
const int tempPin = A0;
const int lightPin = A1;
const int potPin = A2;

unsigned long previousTime = 0;
const unsigned long interval = 1000;

void setup() {
  Serial.begin(9600);
  Serial.println("Time(s),Temperature(C),Light(%),Pot(%)");
}

void loop() {
  unsigned long now = millis();

  if (now - previousTime >= interval) {
    previousTime = now;

    int tempRaw = analogRead(tempPin);
    int lightRaw = analogRead(lightPin);
    int potRaw = analogRead(potPin);

    float temperature = tempRaw * 50.0 / 1023.0;
    float light = lightRaw * 100.0 / 1023.0;
    float pot = potRaw * 100.0 / 1023.0;

    Serial.print(now / 1000.0, 1);
    Serial.print(",");
    Serial.print(temperature, 2);
    Serial.print(",");
    Serial.print(light, 2);
    Serial.print(",");
    Serial.println(pot, 2);
  }
}
