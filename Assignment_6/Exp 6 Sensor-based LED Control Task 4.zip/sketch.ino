int sensor=A1, led=8;
int low=300, high=350;
bool ledOn=false;

void setup() {
  pinMode(led,OUTPUT);
  Serial.begin(9600);
}
void loop() {
  int v=analogRead(sensor);
  if(v<low) ledOn=true;
  else if(v>high) ledOn=false;
  digitalWrite(led,ledOn);
  Serial.println(ledOn?"ON":"OFF");
  delay(100);
}