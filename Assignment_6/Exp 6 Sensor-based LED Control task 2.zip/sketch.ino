int sensor=A1, led=8;
int limit=300;

void setup() {
  pinMode(led,OUTPUT);
}
void loop() {
  int v=analogRead(sensor);
  digitalWrite(led,v<limit);
}