int sensor=A1, led=8;
int limit=300;

void setup() {
  pinMode(led,OUTPUT);
  Serial.begin(9600);
}
void loop() {
  int v=analogRead(sensor);
  bool on=v<limit;
  digitalWrite(led,on);
  Serial.print(v);
  Serial.print("  LED: ");
  Serial.println(on?"ON":"OFF");
  delay(500);
}