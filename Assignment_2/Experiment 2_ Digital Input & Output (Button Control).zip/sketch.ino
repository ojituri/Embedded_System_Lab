int buttonPin = 2;
int ledPin = 8;

int reading;
int buttonState = HIGH;
int lastReading = HIGH;
int ledState = LOW;

int pressCount = 0;

unsigned long lastTime = 0;
unsigned long debounceDelay = 50;

void setup() {
  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(ledPin, OUTPUT);

  Serial.begin(9600);
}

void loop() {
  reading = digitalRead(buttonPin);

  if (reading != lastReading) {
    lastTime = millis();
  }

  if (millis() - lastTime > debounceDelay) {
    if (reading != buttonState) {
      buttonState = reading;

      if (buttonState == LOW) {
        ledState = !ledState;
        digitalWrite(ledPin, ledState);

        pressCount++;
        Serial.print("Button presses: ");
        Serial.println(pressCount);
      }
    }
  }

  lastReading = reading;
}