int leds[] = {8, 9, 10, 11, 12};

void setup() {
  for (int i = 0; i < 5; i++) {
    pinMode(leds[i], OUTPUT);
  }
}

void loop() {
  int count = 0;

  while (count < 10) {
    for (int i = 0; i < 5; i++) {
      if (i % 2 == 0) {
        digitalWrite(leds[i], HIGH);
      } else {
        digitalWrite(leds[i], LOW);
      }
    }

    delay(500);

    for (int i = 0; i < 5; i++) {
      if (i % 2 == 0) {
        digitalWrite(leds[i], LOW);
      } else {
        digitalWrite(leds[i], HIGH);
      }
    }

    delay(500);
    count++;
  }
}