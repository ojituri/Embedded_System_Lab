int leds[] = {8, 9, 10, 11, 12};

void setup() {
  for (int i = 0; i < 5; i++) {
    pinMode(leds[i], OUTPUT);
  }
}

void loop() {
  for (int number = 0; number < 32; number++) {
    for (int i = 0; i < 5; i++) {
      int bitValue = bitRead(number, i);
      digitalWrite(leds[i], bitValue);
    }

    delay(500);
  }
}