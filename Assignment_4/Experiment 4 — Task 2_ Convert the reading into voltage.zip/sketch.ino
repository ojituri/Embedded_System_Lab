int potPin = A0;
int potValue = 0;
float voltage = 0;

void setup() {
  Serial.begin(9600);
}

void loop() {
  potValue = analogRead(potPin);
  voltage = potValue * 5.0 / 1023;

  Serial.print("ADC Value: ");
  Serial.print(potValue);

  Serial.print(" Voltage: ");
  Serial.println(voltage);

  delay(500);
}