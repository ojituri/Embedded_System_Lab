int potPin = A0;
int potValue = 0;
int percentage = 0;

void setup() {
  Serial.begin(9600);
}

void loop() {
  potValue = analogRead(potPin);
  percentage = map(potValue, 0, 1023, 0, 100);

  Serial.print("Potentiometer: ");
  Serial.print(potValue);

  Serial.print(" Percentage: ");
  Serial.print(percentage);
  Serial.println("%");

  delay(500);
}