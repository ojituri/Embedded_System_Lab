
int relay = 7;
int sensor = A1;
int led = 8;

int light;
bool relayOn = false;
unsigned long lastOffTime = 0;

void setup() {
  pinMode(relay, OUTPUT);
  pinMode(led, OUTPUT);

  // Assumes active-LOW relay
  digitalWrite(relay, HIGH);
  digitalWrite(led, LOW);

  lastOffTime = millis();
}

void loop() {
  light = analogRead(sensor);

  if (light < 300 && !relayOn &&
      millis() - lastOffTime >= 5000) {
    relayOn = true;
  }

  if (light > 400 && relayOn) {
    relayOn = false;
    lastOffTime = millis();
  }

  // Active-LOW relay: LOW = ON
  digitalWrite(relay, relayOn ? LOW : HIGH);
  digitalWrite(led, relayOn ? HIGH : LOW);
}
