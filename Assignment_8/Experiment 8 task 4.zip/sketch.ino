
int relay = 7;
int sensor = A1;

int light;
int relayState = HIGH;

void setup() {
  pinMode(relay, OUTPUT);
  Serial.begin(9600);
  digitalWrite(relay, relayState);
}

void loop() {
  light = analogRead(sensor);

  Serial.println(light);

  if (light < 300) {
    relayState = LOW;
  }

  if (light > 400) {
    relayState = HIGH;
  }

  digitalWrite(relay, relayState);

  delay(200);
}
