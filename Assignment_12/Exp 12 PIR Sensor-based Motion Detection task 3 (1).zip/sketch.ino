
const int pirPin = 2;
const int ledPin = 8;
const int buzzerPin = 9;

unsigned long startTime;
unsigned long alertStart = 0;
int motionCount = 0;

int lastState = LOW;
bool alertActive = false;

void setup() {
  pinMode(pirPin, INPUT);
  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);

  Serial.begin(9600);
  Serial.println("PIR stabilising for 30 seconds...");
  startTime = millis();
}

void loop() {
  unsigned long now = millis();

  // Wait for the PIR sensor to stabilise
  if (now - startTime < 30000) {
    return;
  }

  int state = digitalRead(pirPin);

  // Count only a new motion event
  if (state == HIGH && lastState == LOW) {
    motionCount++;

    Serial.print("Motion event count: ");
    Serial.println(motionCount);

    digitalWrite(ledPin, HIGH);
    digitalWrite(buzzerPin, HIGH);

    alertStart = now;
    alertActive = true;
  }

  // Turn LED and buzzer off after 3 seconds
  if (alertActive && now - alertStart >= 3000) {
    digitalWrite(ledPin, LOW);
    digitalWrite(buzzerPin, LOW);
    alertActive = false;
  }

  lastState = state;
}
