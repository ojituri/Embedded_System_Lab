
const int pirPin = 2;
const int ledPin = 8;
const int buzzerPin = 9;

volatile bool motionFlag = false;

const unsigned long warmupTime = 30000;
const unsigned long lockoutTime = 10000;
const unsigned long alertDuration = 3000;

unsigned long startTime;
unsigned long lastEventTime = 0;
unsigned long alertStart = 0;
unsigned long eventCount = 0;

bool haveEvent = false;
bool alertActive = false;

void motionISR() {
  motionFlag = true;
}

void setup() {
  pinMode(pirPin, INPUT);
  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);

  digitalWrite(ledPin, LOW);
  digitalWrite(buzzerPin, LOW);

  Serial.begin(9600);
  Serial.println("PIR stabilising for 30 seconds...");

  startTime = millis();

  attachInterrupt(digitalPinToInterrupt(2), motionISR, RISING);
}

void loop() {
  unsigned long now = millis();

  if (now - startTime < warmupTime) {
    return;
  }

  // Read and clear the interrupt flag safely
  noInterrupts();
  bool motionDetected = motionFlag;
  motionFlag = false;
  interrupts();

  if (motionDetected) {
    now = millis();

    if (!haveEvent || now - lastEventTime >= lockoutTime) {
      haveEvent = true;
      lastEventTime = now;
      eventCount++;

      Serial.print("Motion event at ");
      Serial.print(now);
      Serial.println(" ms");

      Serial.print("Event count: ");
      Serial.println(eventCount);

      digitalWrite(ledPin, HIGH);
      digitalWrite(buzzerPin, HIGH);

      alertStart = now;
      alertActive = true;
    }
  }

  // Turn off the alert after 3 seconds
  if (alertActive && millis() - alertStart >= alertDuration) {
    digitalWrite(ledPin, LOW);
    digitalWrite(buzzerPin, LOW);
    alertActive = false;
  }
}
