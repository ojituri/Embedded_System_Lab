
const int pirPin = 2;
const int ledPin = 8;
const int buzzerPin = 9;

unsigned long startTime;
unsigned long alertStart = 0;
int motionCount = 0;
int lastState = LOW;
bool alertActive = false;

void setup() {
  pinMode(pirPin, INPUT);
  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);

  Serial.begin(9600);
  Serial.println("PIR stabilising...");
  startTime = millis();
}

void loop() {
  unsigned long now = millis();

  if (now - startTime < 30000) {
    return;
  }

  int state = digitalRead(pirPin);

  if (state == HIGH && lastState == LOW) {
    motionCount++;

    Serial.print("Motion event count: ");
    Serial.println(motionCount);

    digitalWrite(ledPin, HIGH);
    digitalWrite(buzzerPin, HIGH);

    alertStart = now;
    alertActive = true;
  }

  if (alertActive && now - alertStart >= 3000) {
    digitalWrite(ledPin, LOW);
    digitalWrite(buzzerPin, LOW);
    alertActive = false;
  }

  lastState = state;
}
