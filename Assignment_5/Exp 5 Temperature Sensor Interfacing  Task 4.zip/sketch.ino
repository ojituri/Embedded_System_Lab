
void setup() { Serial.begin(9600); }
void loop() {
  float c=analogRead(A0)*5.0/1023*100;
  float f=c*9.0/5+32;
  Serial.print(c); Serial.print(" C, ");
  Serial.println(f);
  delay(1000);
}
