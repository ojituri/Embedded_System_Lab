
#include "DHT.h"
DHT dht(4,DHT11);
void setup() { Serial.begin(9600); dht.begin(); }
void loop() {
  float t=dht.readTemperature();
  float h=dht.readHumidity();
  if(!isnan(t) && !isnan(h)) {
    Serial.print(t); Serial.print(" C, ");
    Serial.print(h); Serial.println(" %");
  }
  delay(1000);
}
