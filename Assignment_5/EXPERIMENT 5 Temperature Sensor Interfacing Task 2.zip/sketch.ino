
void setup() { Serial.begin(9600); }
void loop() {
  int raw=analogRead(A0);
  float c=raw*5.0/1023*100;
  Serial.println(c);
  delay(1000);
}
