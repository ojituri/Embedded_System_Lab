long t;

void setup() {
  pinMode(6, OUTPUT);
  pinMode(7, INPUT);
  Serial.begin(9600);
}

void loop() {
  digitalWrite(6, LOW); delayMicroseconds(2);
  digitalWrite(6, HIGH); delayMicroseconds(10);
  digitalWrite(6, LOW);
  t = pulseIn(7, HIGH, 30000);
  Serial.println(t);
  delay(500);
}