int trig=6, echo=7, led=8, buzz=9;
bool state=0;

void setup() {
  pinMode(trig,OUTPUT); pinMode(echo,INPUT);
  pinMode(led,OUTPUT); pinMode(buzz,OUTPUT);
  Serial.begin(9600);
}

void loop() {
  digitalWrite(trig,LOW); delayMicroseconds(2);
  digitalWrite(trig,HIGH); delayMicroseconds(10);
  digitalWrite(trig,LOW);

  long t=pulseIn(echo,HIGH,30000);
  if(t==0){ Serial.println("Out of range"); return; }

  float d=t*0.034/2;
  Serial.print("Distance: "); Serial.println(d);

  if(d<10){ digitalWrite(led,HIGH); digitalWrite(buzz,HIGH); }
  else if(d<=30){ digitalWrite(buzz,LOW); state=!state; digitalWrite(led,state); }
  else{ digitalWrite(led,LOW); digitalWrite(buzz,LOW); }

  delay(500);
}