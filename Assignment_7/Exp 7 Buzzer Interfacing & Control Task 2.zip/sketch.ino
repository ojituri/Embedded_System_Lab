
void setup() { pinMode(9,OUTPUT); }
void loop() {
  for(int i=0;i<5;i++) {
    digitalWrite(9,HIGH); delay(200);
    digitalWrite(9,LOW); delay(200);
  }
  delay(2000);
}
