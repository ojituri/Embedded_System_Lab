
void setup() { pinMode(9,OUTPUT); }
void beep(int on,int off) { digitalWrite(9,HIGH); delay(on); digitalWrite(9,LOW); delay(off); }
void loop() {
  beep(1000,500);
  for(int i=0;i<2;i++) beep(200,200);
  for(int i=0;i<3;i++) beep(200,200);
  for(int i=0;i<3;i++) beep(600,200);
  for(int i=0;i<3;i++) beep(200,200);
  delay(2000);
}
