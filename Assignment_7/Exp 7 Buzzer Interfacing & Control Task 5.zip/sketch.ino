
bool silenced=false;
void setup() { pinMode(2,INPUT_PULLUP); pinMode(9,OUTPUT); }
void loop() {
  int light=analogRead(A1);
  if(light>=300) silenced=false;
  if(digitalRead(2)==LOW) silenced=true;
  digitalWrite(9,light<300 && !silenced);
  delay(50);
}
