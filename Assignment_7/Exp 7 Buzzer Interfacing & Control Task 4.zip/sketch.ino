
void setup() { pinMode(9,OUTPUT); Serial.begin(9600); }
void loop() {
  int light=analogRead(A1);
  digitalWrite(9,light<300 ? HIGH : LOW);
  Serial.println(light);
  delay(100);
}
