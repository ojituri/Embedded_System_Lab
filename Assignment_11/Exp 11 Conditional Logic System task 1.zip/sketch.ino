
const int tempPin = A0;
const int lightPin = A1;
const int buttonPin = 2;
const int relayPin = 7;
const int led1Pin = 8;
const int buzzerPin = 9;
const int led2Pin = 10;

void setup() {
  pinMode(buttonPin, INPUT_PULLUP);
  pinMode(relayPin, OUTPUT);
  pinMode(led1Pin, OUTPUT);
  pinMode(led2Pin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int tempRaw = analogRead(tempPin);
  int lightRaw = analogRead(lightPin);

  float temperature = tempRaw * 50.0 / 1023.0;
  int light = map(lightRaw, 0, 1023, 0, 100);

  bool night = light < 30;
  bool fan = false;

  if (temperature < 30) {
    digitalWrite(led1Pin, HIGH);
    digitalWrite(led2Pin, LOW);
    fan = false;
  }
  else if (temperature < 35) {
    digitalWrite(led1Pin, HIGH);
    digitalWrite(led2Pin, LOW);
    fan = true;
  }
  else {
    digitalWrite(led1Pin, LOW);
    digitalWrite(led2Pin, HIGH);
    fan = true;
  }

  digitalWrite(relayPin, fan ? HIGH : LOW);

  if (temperature >= 35 && !night) {
    tone(buzzerPin, 1000);
  } else {
    noTone(buzzerPin);
  }

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.print(" C, Light: ");
  Serial.print(light);
  Serial.print("%, Fan: ");
  Serial.println(fan ? "ON" : "OFF");

  delay(500);
}
