
const int tempPin = A0;
const int lightPin = A1;
const int relayPin = 7;
const int led1Pin = 8;
const int buzzerPin = 9;
const int led2Pin = 10;

enum State { NORMAL, WARM, HOT };

void setup() {
  pinMode(relayPin, OUTPUT);
  pinMode(led1Pin, OUTPUT);
  pinMode(led2Pin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  int tempRaw = analogRead(tempPin);
  int lightRaw = analogRead(lightPin);

  float temperature = tempRaw * 50.0 / 1023.0;
  int light = map(lightRaw, 0, 1023, 0, 100);

  State state;

  if (temperature < 30) {
    state = NORMAL;
  } else if (temperature < 35) {
    state = WARM;
  } else {
    state = HOT;
  }

  bool night = light < 30;
  bool fan = false;

  switch (state) {
    case NORMAL:
      digitalWrite(led1Pin, HIGH);
      digitalWrite(led2Pin, LOW);
      fan = false;
      break;

    case WARM:
      digitalWrite(led1Pin, HIGH);
      digitalWrite(led2Pin, LOW);
      fan = true;
      break;

    case HOT:
      digitalWrite(led1Pin, LOW);
      digitalWrite(led2Pin, HIGH);
      fan = true;
      break;
  }

  digitalWrite(relayPin, fan ? HIGH : LOW);

  if (state == HOT && !night) {
    tone(buzzerPin, 1000);
  } else {
    noTone(buzzerPin);
  }

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.print(" C, Light: ");
  Serial.print(light);
  Serial.print("%, State: ");

  switch (state) {
    case NORMAL: Serial.println("NORMAL"); break;
    case WARM: Serial.println("WARM"); break;
    case HOT: Serial.println("HOT"); break;
  }

  delay(500);
}
