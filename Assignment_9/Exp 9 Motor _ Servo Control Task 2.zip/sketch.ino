#include <Servo.h>
Servo s;

void setup() {
  s.attach(9);
}

void loop() {
  int x=analogRead(A0);
  int a=map(x,0,1023,0,180);
  s.write(a);
  delay(20);
}