int f=6,r=7,stop=8,btn=2;
bool rev=false;

void setup() {
  pinMode(f,OUTPUT); pinMode(r,OUTPUT);
  pinMode(stop,OUTPUT); pinMode(btn,INPUT_PULLUP);
}

void loop() {
  if(digitalRead(btn)==LOW) {
    rev=!rev;
    delay(300);
  }
  digitalWrite(f,!rev); digitalWrite(r,rev);
  digitalWrite(stop,LOW);
}